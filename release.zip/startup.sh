#!/bin/bash
streamlit run app.py --server.port=$PORT --server.enableCORS=false